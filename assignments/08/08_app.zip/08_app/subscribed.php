<?php
include('header.html');
?>

    <!--  Content  -->
    <main id="content">

            <h2 class="center">Thank you!</h2>
            <blockquote>You will now receive our monthly newsletter filled with special offers, enjoyable articles, and healthy recipies.
        </blockquote>
        
        
     

    </main>
    <?php
include('footer.html');
?>