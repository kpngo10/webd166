<script type='text/javascript'>
    window.location = "index.php#content";
</script>